#include "Casino.h"

static unsigned int stateCasino;
static char timerCasino, timerSystem;
static char option, timestamp;
static char casinoTokens[6], newNum, c, add;
static int toBet, systemTime, timeToSound, number, cell, numberTranslated;
char sendTokens[4], sendTime[5], sendTimestamp[3], sendAudio[3], sendADC[5], sendNewNum[2], sendTrans[5];
static char sendCell[5];
static char audioPeriod;
static unsigned char gamesPlayed;
static char sendGamesPlayed[4], sendTokensLost[4], sendTokensWon[4];

int myAtoi(char *str) {  
    int res = 0; // Initialize result  
    int i;
  
    // Iterate through all characters of input string and  
    // update result  
    for (i = 0; str[i] != '\0'; ++i)  
        res = res*10 + str[i] - '0';  

    // return result.  
    return res;  
}  

void mainMenu(void){
    SiPutsCooperatiu("\r\n---------------\r\n\0");
    SiPutsCooperatiu("Main menu\0");
    SiPutsCooperatiu("\r\n---------------\r\n\0");
    SiPutsCooperatiu("\r\n\0");
    SiPutsCooperatiu("Choose an option\r\n\0");
    SiPutsCooperatiu("\t1. New bet\r\n\0");
    SiPutsCooperatiu("\t2. Add or remove tokens\r\n\0");
    SiPutsCooperatiu("\t3. Show statistics\r\n\0");
    SiPutsCooperatiu("\tOption: \0");
}

void betMenu(void){
    SiPutsCooperatiu("Welcome to the LSCasino\r\n\0");
    SiPutsCooperatiu("\tPress ""*"" to return to the main menu\r\n\0");
    SiPutsCooperatiu("\tPress ""#"" to bet tokens\r\n\0");
    SiPutsCooperatiu("\r\n\0");
}

void introduceTokens(void){
    SiPutsCooperatiu("\r\nIntroduce the number of tokens to bet: \0");
}

void introduceCell(void){
    SiPutsCooperatiu("\r\nIntroduce the cell [1-36 = individual | 100 - Red | 200 - Black]: \0");
}

void rouletteMenu(void){
    SiPutsCooperatiu("\r\nStarting the roulette...\r\n\0");
    SiPutsCooperatiu("The winning cell is number \r\n\0");
    SiPutsCooperatiu("\r\n\0");
    SiPutsCooperatiu("Choose an option\r\n\0");
    SiPutsCooperatiu("\t1. New bet\r\n\0");
    SiPutsCooperatiu("\t2. Add or remove tokens\r\n\0");
    SiPutsCooperatiu("\t3. Show statistics\r\n\0");
    SiPutsCooperatiu("\tOption: \0");
}

void addOrRemove(void){
    SiPutsCooperatiu("\r\n\tIntroduce a value and press ""#"" to add tokens"); 
    SiPutsCooperatiu("\r\n\tor ""*"" to remove tokens.\r\n\0");
}

void initCasino(void){
    timerCasino = TiGetTimer();
    timerSystem = TiGetTimer();
    TiResetTics(timerSystem);
    systemTime = 0;
    stateCasino = 0;
    gamesPlayed = 0;
    changeAudioStatus();
    //changeServoStatus();
}

void MotorCasino(void) {
    switch(stateCasino) {
        case 0:
            mainMenu();
            stateCasino = 1;
        break;
        case 1:
            // If there are any characters to be read, read them, if they are valid then to action
            // however if they are outside of range then send them back to the pc.
            if (SiCharAvail() != 0){
                option= SiGetChar();
                if ((option <= '3') && (option >= '1')){
                    stateCasino = option-'0'+1;
                    TiResetTics(timerCasino);
                }                
                SiSendChar(option);   
                SiSendChar('\n');
            }
            setWaitingBet(0);
            setAddOrRemove(0);
            //stateCasino = 100;
            break;
        case 100:
            if(getPress() == 1) {
                option = getNumber();
                if ((option <= '3') && (option >= '1')){
                    stateCasino = option-'0'+1;
                    TiResetTics(timerCasino);
                }                     
                SiSendChar(option);   
                SiSendChar('\n');
                resetPress();
            }
            stateCasino = 1;
        break;
        case 2:
            //Option 1 - new bet
            if(TiGetTics(timerCasino) >= 200) {
                SiPutsCooperatiu("\r\n");
                betMenu();
                SiPutsCooperatiu("\r\tTokens Available: ");
                mymyItoa(getTokens(), 3, sendTokens);
                SiPutsCooperatiu(sendTokens);                      
                SiPutsCooperatiu("\r\n\n");
                stateCasino = 21;
                timestamp = 16;
                TiResetTics(timerCasino);
            }
            break;

        case 3:
            //Option 2 - Add or remove casinoTokens
            setAddOrRemove(1);
            if(TiGetTics(timerCasino) >= 100) {
                addOrRemove();
                stateCasino = 31;
                TiResetTics(timerCasino);                
            }
            break;

           // LCD TESTING
                                      
        case 4:        
            //Option 3 - Show statistics
            if (TiGetTics(timerCasino) > 20){                
                SiPutsCooperatiu("\r\n\tStatistics panel:\r\n");
                SiPutsCooperatiu("\tActual Tokens: ");
                mymyItoa(getTokens(), 3, sendTokens);
                SiPutsCooperatiu(sendTokens);
                stateCasino = 41;                          
            }
            break;
        case 41:
            SiPutsCooperatiu("\r\n\tPlayed games: ");
            mymyItoa(gamesPlayed, 3, sendGamesPlayed);
            SiPutsCooperatiu(sendGamesPlayed);    
            stateCasino = 42;    
            break;            
        case 42:
            SiPutsCooperatiu("\r\n\t\tTokens won in total: ");
            mymyItoa(gamesPlayed, 3, sendTokensWon);
            SiPutsCooperatiu(sendTokensWon);     
            stateCasino = 43;              
            break;
        case 43:
            SiPutsCooperatiu("\r\n\t\tTokens lost in total: ");
            mymyItoa(gamesPlayed, 3, sendTokensLost);
            SiPutsCooperatiu(sendTokensLost);    
            SiPutsCooperatiu("\r\n\t\tSystem time: ");
            mymyItoa(systemTime, 4, sendTime);
            SiPutsCooperatiu(sendTime);
            SiPutsCooperatiu("s");    
            stateCasino = 44;   
            TiResetTics(timerCasino);
            break;
        case 44:
            if(TiGetTics(timerCasino) >= 1000) {
                SiPutsCooperatiu("\r\t\tSystem time: ");
                mymyItoa(systemTime, 4, sendTime);
                SiPutsCooperatiu(sendTime);
                SiPutsCooperatiu("s");
                TiResetTics(timerCasino);
            }
            if (SiCharAvail() != 0){
                if (SiGetChar() == 27){
                    mainMenu();
                    stateCasino = 1;
                }
            }  
            if((getPress() == 1) && (getAsterisc() == 1)) {
                    stateCasino=1;
                    resetPress();                    
                    mainMenu();
            }                         
            break;  
        case 21:
            if(TiGetTics(timerCasino) >= 1000) {
                // Write the value of timestamp in ASCII to the temp variable
                mymyItoa(timestamp, 2, sendTimestamp);
                setWaitingBet(1);
                // Send an individual character through the EUSART
                SiPutsCooperatiu("\r[Remaining time ");
                // Send an array of characters (or string) through the EUSART
                SiPutsCooperatiu(sendTimestamp);
                SiPutsCooperatiu(" seconds]");
                TiResetTics(timerCasino);                
                if (--timestamp == -1) {
                    timestamp=16;
                    stateCasino = 0;
                    break;
                }    
            }

            /*
             * I have absolutely no idea why this doesn't work...
            if((SiCharAvail() != 0) || (getPress() == 1)) {
                if((SiGetChar() == 27) || (getAsterisc() == 1)) {
                    mainMenu();
                    stateCasino = 1;                    
                }
            }
            */
            if (SiCharAvail() != 0){             
                if (SiGetChar() == 27){
                    mainMenu();
                    stateCasino = 1;
                }
                if (SiGetChar() == 'r'){
                    stateCasino = 22;
                }     
                break;           
            }
            if((getPress() == 1) && (getAsterisc() == 1)) {
                    stateCasino=1;
                    resetPress();
                    mainMenu();
                    break;
            }
            if((getPress() == 1) && (getHashtag() == 1)) {
                    stateCasino=22;
                    resetPress();
            }            
            break;
        case 22: 
            setRoulette(1);
            introduceTokens();
            newNum = 0;
            gamesPlayed++;
            stateCasino = 23;
            setWaitingBet(0);            
            break;
        case 23:
            if (SiCharAvail() != 0) {                 
                c = SiGetChar();             
                if((c == '\n') || (c == '\r')) {                 
                    casinoTokens[newNum] = '\0';
                    if(toBet <= getTokens()) {
                        SiPutsCooperatiu("\r\n\tTokens are betted\n\n");
                        stateCasino = 24;
                        TiResetTics(timerCasino);
                    } else {
                        SiPutsCooperatiu("\r\n\tInsufficient saldo\n\n");
                        stateCasino = 0;                             
                    }  
                    break;             
                } else {
                    casinoTokens[newNum++] = c;
                    SiSendChar(casinoTokens[newNum-1]);
                }
            }
            if (SiCharAvail() != 0){
                if (SiGetChar() == 27){
                    mainMenu();
                    stateCasino=1;
                }
            }
            if((getPress() == 1) && (getAsterisc() == 1)) {
                    stateCasino=1;
                    resetPress();
                    mainMenu();
            }   
            break;
        case 24: 
            introduceCell();
            newNum = 0;
            stateCasino = 25;
            break;    
        case 25:
            if (SiCharAvail() != 0) {
                c = SiGetChar();             
                if((c == '\n') || (c == '\r')) {
                    sendCell[newNum] = '\0';
                    cell = myAtoi(sendCell);
                    if( ((cell <= 36) && (cell >= 0)) || (cell == 100) || (cell == 200)) {
                        stateCasino = 26;
                        TiResetTics(timerCasino);
                        SiPutsCooperatiu("\r\n");
                        mymyItoa(toBet, 3, casinoTokens);
                        SiPutsCooperatiu(casinoTokens);             
                        SiPutsCooperatiu(" tokens have been bet on ");
                        mymyItoa(cell, 3, sendCell);
                        if(cell == 100) {
                            sendCell[0] = 'r';
                            sendCell[1] = 'e';
                            sendCell[2] = 'd';
                            sendCell[3] = '\0';                                                                                    
                        }
                        if(cell == 200) {
                            sendCell[0] = 'b';
                            sendCell[1] = 'l';
                            sendCell[2] = 'a';
                            sendCell[3] = 'c';
                            sendCell[4] = 'k';                                                                                    
                        }                                              
                        SiPutsCooperatiu(sendCell);       
                        SiPutsCooperatiu("!\r\n");
                    } else {
                        SiPutsCooperatiu("\r\n\tInvalid option...\n\n");
                        stateCasino = 0;                             
                    }               
                } else {
                    sendCell[newNum++] = c;
                    SiSendChar(sendCell[newNum-1]);
                }
            }
            if (SiCharAvail() != 0){
                if (SiGetChar() == 27){
                    mainMenu();
                    stateCasino=1;
                }
            }
            if((getPress() == 1) && (getAsterisc() == 1)) {
                    stateCasino=1;
                    resetPress();
                    mainMenu();
            }   
            break;   
        case 26:
            
            audioPeriod = 1;            
            timeToSound = getADConversion()*2;
            SiPutsCooperatiu("\r\nADC value: ");                
            mymyItoa(timeToSound, 4, sendADC);
            SiPutsCooperatiu(sendADC);
            setAudioPeriode(audioPeriod);
            changeAudioStatus();
            stateCasino = 27;   
            TiResetTics(timerCasino);   

            break;                     
        case 27:
            if(TiGetTics(timerCasino) >= timeToSound) {
                if(audioPeriod >= 3) {
                    changeAudioStatus();
                    stateCasino = 28; 
                } else {
                    audioPeriod++;
                    mymyItoa(audioPeriod, 2, sendAudio);

                    timeToSound = getADConversion()*2;
                    SiPutsCooperatiu("\r\nADC value: ");                
                    mymyItoa(timeToSound, 4, sendADC);                    
                    SiPutsCooperatiu(sendADC);

                    SiPutsCooperatiu("\r\nAudio period: ");                
                    SiPutsCooperatiu(sendAudio);
                    setAudioPeriode(audioPeriod);
                }
                TiResetTics(timerCasino);
            }
            break;
        case 28:
            number = rand() % 36;

            SiPutsCooperatiu("\r\nInitially: ");                
            mymyItoa(number, 4, sendTime);                    
            SiPutsCooperatiu(sendTime);

            numberTranslated = translate(number);

            SiPutsCooperatiu("\r\nRandom number after: ");                
            mymyItoa(numberTranslated, 4, sendTrans);                    
            SiPutsCooperatiu(sendTrans);

            changeServoStatus();
            stateCasino = 29;
            break;
        case 29:
           if(cell == 100) {
               if(numberTranslated % 2 == 0) {
                   correctColor(toBet);
               } else {
                   incorrectBet(toBet);
               }
           } else if(cell == 200) {
               if(numberTranslated % 2 == 1) {
                   correctColor(toBet);                                
               } else {
                   incorrectBet(toBet);
               }
           } else {
               if(cell == number) {
                   correctCell(toBet);
               } else {
                   incorrectBet(toBet);
               }                   
           }    
            TiResetTics(timerCasino);
           stateCasino = 210;         
        case 210:
            if(TiGetTics(timerCasino) >= 3000) {
                TiResetTics(timerCasino);
                audioPeriod = 4;            
                timeToSound = getADConversion()*2;
                SiPutsCooperatiu("\r\nADC value: ");                
                mymyItoa(timeToSound, 4, sendADC);
                SiPutsCooperatiu(sendADC);
                setAudioPeriode(audioPeriod);
                changeAudioStatus();
                stateCasino = 211;             
            }
            break;                 
        case 211:            
            if(TiGetTics(timerCasino) >= timeToSound) {
                if(audioPeriod <= 2) {
                    changeAudioStatus();
                    stateCasino = 0; 
                    setRoulette(0);  
                } else {
                    audioPeriod--;
                    mymyItoa(audioPeriod, 2, sendAudio);

                    timeToSound = getADConversion()*2;
                    SiPutsCooperatiu("\r\nADC value: ");                
                    mymyItoa(timeToSound, 4, sendADC);                    
                    SiPutsCooperatiu(sendADC);

                    SiPutsCooperatiu("\r\nAudio period: ");                
                    SiPutsCooperatiu(sendAudio);
                    setAudioPeriode(audioPeriod);
                }
                TiResetTics(timerCasino);
            }
            break;                                  
        case 31:
            if(SiCharAvail() != 0) {
                if(SiGetChar() == 'a') {
                    add = 1;
                    stateCasino = 32;
                }
                if(SiGetChar() == 'r') {
                    add = 0;
                    stateCasino = 32;
                }          
                SiPutsCooperatiu("\tTokens: ");
                newNum = 0;       
            }
            if (getPress() == 1) {
                if(getAsterisc() == 1) add = 0;
                if(getHashtag() == 1) add = 1;                    
                SiPutsCooperatiu("\tTokens: ");        
                stateCasino = 32;     
                resetPress();
                newNum = 0;
            }
            break;                
        case 32:
            if (SiCharAvail() != 0) {
                c = SiGetChar();             
                if((c == '\n') || (c == '\r')) {
                    casinoTokens[newNum] = '\0';                   
                    if(add) {
                        addTokens(myAtoi(casinoTokens));
                        SiPutsCooperatiu("\r\n\tWe have added the tokens!\n\n");
                    } else {
                        removeTokens(myAtoi(casinoTokens));
                        SiPutsCooperatiu("\r\n\tWe have removed the tokens!\n\n");
                    }
                    stateCasino = 0;  
                    break;                  
                } else {
                    casinoTokens[newNum++] = c;
                    SiSendChar(casinoTokens[newNum-1]);
                }
            }
            if (SiCharAvail() != 0){
                if (SiGetChar() == 27){
                    mainMenu();
                    stateCasino=1;
                }
            }
            if((getPress() == 1) && (getAsterisc() == 1)) {
                    stateCasino=1;
                    resetPress();
                    mainMenu();
            }            
            break;             
    }
}

void MotorSystemTime(void) { 
    if(TiGetTics(timerSystem) >= 1000) {
        systemTime++;
        TiResetTics(timerSystem);
    }
}


#define     MAXCOLUMNES 16
static char stateLCD = 0;
const unsigned char waiting[]={"Waiting for bet!"};
const unsigned char playing[]={"Playing...      "};
static unsigned char menu[30]; //28
static unsigned char addremovetokens[]={"Adding or removing tokens "}; //26
static unsigned char timerLCD, caracterInici, i,j;
static unsigned char segonaLinia[MAXCOLUMNES];
static char waitingBet, checkTime, roulette;
static char addremove;


void initMotorLCD(void){
    //Pre: El LCD est� inicialitzat
    timerLCD = TiGetTimer();
    caracterInici = 0;
    LcClear();
    //Hi ha caselles de la segona l�nia que sempre valdran el mateix, les preparo!
    initMenu();
    waitingBet = 0;
    roulette = 0;
    checkTime = 0;
    addremove = 0;
}


void MotorLCD(void){
    switch (stateLCD){
        case 0:
            LcPutChar(menu[j++]);
            if (j==30) j= 0;
            if (i++ > MAXCOLUMNES) {
                stateLCD = 1;
                TiResetTics(timerLCD);
            }
            break;

        case 1: //Preparo el string
            mymyItoa(getTokens(), 3, sendTokens);
            menu[12] = sendTokens[0];
            menu[13] = sendTokens[1];
            menu[14] = sendTokens[2];
            menu[25] = '2';
            menu[26] = '6';
            stateLCD = 2;
            break;
        case 2:
            if (TiGetTics(timerLCD)>50){
                TiResetTics(timerLCD);
                i=0;
                stateLCD = 3;
            }
            break;
        case 3:
            if(waitingBet == 1) {
                LcPutChar(waiting[i++]);
                if (i > MAXCOLUMNES) {
                    stateLCD = 4;
                    TiResetTics(timerLCD);
                }
            } else {
                stateLCD = 10;
            }
            break;            
        case 4:
            if(TiGetTics(timerLCD) >= 50) {
                stateLCD = 5;
            }
            break;            
        case 5:            
            stateLCD = 6;
            i = 0;
            LcGotoXY(0,1);
            break;                            
        case 6:
            LcPutChar(255);
            if(i++ > MAXCOLUMNES) {
                stateLCD = 7;
                checkTime = 15;
                LcGotoXY(15,1);
            }
            break;
        case 7:
            if(checkTime == timestamp) {
                LcPutChar(32);
                stateLCD = 8; 
                break;    
            }            
            if(waitingBet == 0) {
                stateLCD = 0;
                break;
            }
            if(roulette == 1) {
                LcGotoXY(0,0);
                i = 0;
                stateLCD = 11;
                break;
            }            
            break;
        case 8:
            if(checkTime-- <= 0) {
                stateLCD = 10;
                setWaitingBet(0);
                TiResetTics(timerLCD);                                
            } else {
                stateLCD = 7;                
                LcGotoXY(checkTime, 1);
            }
        break;      
        case 10:
            if (TiGetTics(timerLCD)>= 250){
                caracterInici++;
                if (caracterInici==30)
                    caracterInici=0;
                stateLCD = 0;
                LcGotoXY(0,0);
                j = caracterInici;
                i=0;
            }
            if(addremove == 1) {
                stateLCD = 20;
            }
            break;
        case 11:
            if(roulette == 1) {
                LcPutChar(playing[i++]);
                if (i > MAXCOLUMNES) {
                    i = 0;
                    stateLCD = 12;
                    LcGotoXY(0,1);
                    TiResetTics(timerLCD);
                }                 
            } else {
                stateLCD = 10;                
            }
            break;  
        case 12:
        if(TiGetTics(timerLCD) >= 50) {
            TiResetTics(timerLCD);
            stateLCD = 13;
        }
            break;            
        case 13:
            LcPutChar(32);
            if (i++ > MAXCOLUMNES) {
                i = 0;
                stateLCD = 14;
            }                 
            break;              
        case 14:            
            if(roulette == 0) {
                initMenu();
                LcGotoXY(0,0);
                stateLCD = 0;
            }                
        break;
        case 20:
            j = 0;
            i = 0;
            caracterInici = 0;
            stateLCD = 21;
            break;
        case 21:
                LcPutChar(addremovetokens[j++]);
                if (j==26) j=0;
                if (i++ > MAXCOLUMNES) {
                    stateLCD = 22;
                    TiResetTics(timerLCD);
                    i=0;
                }        
            break;      
        case 22:
            if (TiGetTics(timerLCD)>= 300){
                caracterInici++;
                if (caracterInici==26)
                    caracterInici=0;
                stateLCD = 21;
                LcGotoXY(0,0);
                j = caracterInici;
                i=0;
            }
            if(addremove == 0) {
                TiResetTics(timerLCD);
                stateLCD = 23;
            }        
            break;
        case 23:
            if(TiGetTics(timerLCD) >= 50) {
                initMenu();
                LcGotoXY(0,0);                
                stateLCD = 0;
            }
            break;            


    }
}

void initMenu(void) {
    mymyItoa(getTokens(), 3, sendTokens);
    menu[12] = sendTokens[0];
    menu[13] = sendTokens[1];
    menu[14] = sendTokens[2];
    menu[25] = '2';
    menu[26] = '6';

    menu[0] = 'M';
    menu[1] = 'a';
    menu[2] = 'i';
    menu[3] = 'n';
    menu[4] = ' ';
    menu[5] = 'm';
    menu[6] = 'e';
    menu[7] = 'n';
    menu[8] = 'u';    
    menu[9] = ' ';
    menu[10] = '-';
    menu[11] = ' ';    

    menu[15] = ' ';
    menu[16] = 't';    
    menu[17] = 'o';
    menu[18] = 'k';
    menu[19] = 'e';        
    menu[20] = 'n';
    menu[21] = 's';        
    menu[22] = ' ';        
    menu[23] = '-';
    menu[24] = ' ';
    menu[27] = 223;
    menu[28] = 'C';
    menu[29] = ' ';        
}


void setWaitingBet(char set)  {
    waitingBet = set;
}

void setRoulette(char set)  {
    roulette = set;
}

void setAddOrRemove(char set)  {
    addremove = set;
}
