/* 
 * File:   Servo.h
 * Author: Fabsibabs
 *
 * TAD que fa encendre un led com si fos un heartbeat. Em serveix per veure si
 * el micro s'ha quedat penjat
 *
 * Created on 25 de enero de 2014, 23:02
 */

#ifndef SERVO_H
#define	SERVO_H
#include <xc.h>
#include "time.h"
#include "SiTSio.h"
#include "intAscii.h"

#define PERIOD  20 

#define TURN_ON()  TRISAbits.TRISA4=0;
#define STOP() LATAbits.LATA4=0;
#define SPIN() LATAbits.LATA4=1;

void ServoInit();
void MotorServo();
void changeServoStatus();
void setNumber(int number);
int translate(int userBet);


#endif	/* SERVO */

