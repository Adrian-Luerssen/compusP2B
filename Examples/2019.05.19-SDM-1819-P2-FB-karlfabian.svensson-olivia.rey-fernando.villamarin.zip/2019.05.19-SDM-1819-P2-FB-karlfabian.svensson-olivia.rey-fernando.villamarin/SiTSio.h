//-----------------------------------------------------------------
//TAD         :Canal serie, placa base del robot OMNIA
//Autor       :FEC & JNM
//Descripcio  :El tipic i llegendari TadSio, transmissio per recepcio
// amb una cua de recepcio pero, de moment, les transmissions s'esperen
// fins acabar la transmissio anterior, <-- JA NO :) Tenim la fantastica
// funcio SiPutsCooperatiu
//Prefix      :Si
//Data        :Wednesday, March 2, 2010
//-----------------------------------------------------------------
//
#ifndef SITSIO_H
#define	SITSIO_H

#include <xc.h>
#include "time.h"

#define BUFFER_RX_SIZE   64
#define BUFFER_TX_SIZE  128


//
//--------------------------------PUBLIQUES---AREA-----------
//

void MotorSIO(void);

int SiCharAvail(void);
// Pre: retorna el nombre de caracters rebuts que no s'han recollit
// amb la funcio GetChar encara

char SiGetChar(void);
// Pre: SiCharAvail() es major que zero
// Post: Treu i retorna el primer caracter de la cua de recepcio.

void SiSendChar(char c);
// Post: espera que el caracter anterior s'hagi enviat i envia aquest

void SiPuts(char *s);
// Post: Usa SiSendchar

void SiInit(void);
//Post: Inicialitza la SIO als pins RP2 (Tx) i RP4(Rx)



//Provo de fer un invent cooperatiu ja que si char *s es molt llarg
//Amorro tots els motors cooperatius

void SiPutsCooperatiu(char *s);
    //Pre: La referencia de char *s es o be un const char o be puc garantir que
    //     no es sobreescriure fins que no l'hagi enviat...
    //Post: Encua *s a la cua de cadenes per enviar...

void MotorSIO(void);

//
//---------------------------End--PUBLIQUES---AREA-----------
//

//
//--------------------------------PRIVADES----AREA-----------
//

//
//---------------------------End--PRIVADES----AREA-----------
//

#endif	/* SITSIO_H */