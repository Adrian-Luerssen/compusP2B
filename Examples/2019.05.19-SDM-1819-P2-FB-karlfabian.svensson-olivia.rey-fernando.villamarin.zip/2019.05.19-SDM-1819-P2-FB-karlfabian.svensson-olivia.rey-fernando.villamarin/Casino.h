/* 
 * File:   PrTPropaganda.h
 * Author: JNM
 *
 * Placa de test per al PIC18F4321 controla el backlight del LCD, te un menu
 * interactiu pel SIO, i refresca l'estat dels periferics (2 pulsadors, 2 switchos,
 * 1 entrada analogica)
 * 
 */


#ifndef CASINO_H
#define	CASINO_H
#include <xc.h>
#include <stdlib.h>
#include "SiTSio.h"
#include "AuTAudio.h"
#include "Keypad.h"
#include "Tokens.h"
#include "intAscii.h"
#include "AdTADC.h"
#include "Servo.h"

//Pre: 0<= num <= 9999
//Post: deixa a temp[3..0] el num en ASCII
void Menu(void);
//Pre: La SIO esto inicialitzada
//Post: Pinta el menu pel canal serie

void initCasino(void);
//Pre: La SIO esta inicialitzada
//Post: Inicialitza el timestamp i pinta la propaganda per la SIO

void MotorCasino(void);
void MotorSystemTime(void);

void initMotorLCD(void);
//Pre: el LCD est� inicialitzat
//Post: inicialitza el LCD per posar la marquesina a 0
void MotorLCD(void);


#endif	/* CASINO */

