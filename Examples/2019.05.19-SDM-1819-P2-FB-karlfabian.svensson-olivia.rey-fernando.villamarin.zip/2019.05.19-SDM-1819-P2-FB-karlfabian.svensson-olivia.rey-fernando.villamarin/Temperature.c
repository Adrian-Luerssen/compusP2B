/*
 * Push button and switch file that we do not need, it controls the illuminosity of the LCT backlight
 * as well as the frecuency of the period.
*/

#include "Temperature.h"


static char stateTemp,timerTemp;
static char i, sendCheck[5], sendTemp[14], sendTest[4];
static int check, temp[14], test, tempTotal;

void initTemp(void){
    TRISAbits.TRISA3 = 1; // Temperature input
    TRISAbits.TRISA2 = 0; // Clock output for temp
    TRISBbits.TRISB11 = 0; // Chip Select output
    clkL();
    csH();
    stateTemp = 6;
    timerTemp = TiGetTimer();
    TiResetTics(timerTemp);
}


void MotorTemp(){
    switch(stateTemp) {
        case 0:
            if(TiGetTics(timerTemp)) {
                TiResetTics(timerTemp);
                clkH();
                stateTemp = 1;                    
            }                                                              
            break;    
        case 1:
            if(TiGetTics(timerTemp)) {
                TiResetTics(timerTemp);
                clkL();
                stateTemp = 2;                  
            }                
            break;
        case 2:
            if(TiGetTics(timerTemp)) {
                TiResetTics(timerTemp);
                clkH();
                stateTemp = 3;                    
            }                                                              
            break;    
        case 3:
            if(TiGetTics(timerTemp)) {
                TiResetTics(timerTemp);
                clkL();
                stateTemp = 4;                  
            }                
            break;
        case 4:
            if(TiGetTics(timerTemp)) {
                TiResetTics(timerTemp);
                clkH();
                stateTemp = 5;                  
            }                                                               
            break;    
        case 5:
            if(TiGetTics(timerTemp)) {
                TiResetTics(timerTemp);
                clkL();
                stateTemp = 6;     
            }                                     
            break;
        case 6:
            if(TiGetTics(timerTemp) >= 500) {
                TiResetTics(timerTemp);
                stateTemp = 12;
                i = 0;        
                tempTotal = 0;
                csL();        
            }
            break;           
        case 8:
            if(TiGetTics(timerTemp)) {
                TiResetTics(timerTemp);
                clkH();                
                stateTemp = 9;  
            }                                                                
            break;    
        case 9:
            if(TiGetTics(timerTemp)) {
                TiResetTics(timerTemp);
                temp[i] = PORTAbits.RA3;
                tempTotal = (tempTotal << 1 & 0xFFFE) | PORTAbits.RA3;                
                if(temp[i] == 1) {
                    sendTemp[12-i] = '1';
                }
                if(temp[i] == 0) {
                    sendTemp[12-i] = '0';                  
                }                 
                i++;
                stateTemp = 12;
                clkL();
            }                                                  
            break;                
        case 12:
            stateTemp = 8;            
            if(i>=13) {
                stateTemp = 13;                
            }
            
            break;
        case 13:
            csH();
            sendTemp[13] = '\0';
            tempTotal *= 0.0625;
            mymyItoa(tempTotal, 3, sendTest);
            /*
            SiPutsCooperatiu("\r\n Temp Dec: ");
            SiPutsCooperatiu(sendTest);              
            SiPutsCooperatiu("\r\n Temperature: ");
            SiPutsCooperatiu(sendTemp);        
            */
            stateTemp = 0;
            break;            
    }             
}

