/*
 * This file was used for the testing board, we can convert it into the SERVO handling file since
 * our servo motor is connected to pin 12 of the pick it which is RA4 of the micro.
*/

#include "Servo.h"



static unsigned char timerServo;
static unsigned char stateServo;
static unsigned char timeToSpin;
static int angle;
static unsigned int counter, warmUp;
static char sendAngle[4];
//static unsigned char number;

void ServoInit(){
    TURN_ON();
    SPIN();
    timerServo = TiGetTimer();
    stateServo = 6;
    timeToSpin = 0;
    counter = 0;
    warmUp = 0;
    angle = 143;
}


void MotorServo() {
    switch(stateServo){
        case 0:
            if (TiGetTics(timerServo)>=3000){
                SPIN();
                TiResetTics(timerServo);
                stateServo = 1;
            }
            break;
        case 1:
            if (TiGetTics(timerServo) >= 2){
                TiResetTics(timerServo);
                STOP();
                stateServo = 2;
            }
            break;

        case 2:
            if (TiGetTics(timerServo) >= 18){
                TiResetTics(timerServo);
                SPIN();
                stateServo = 1;
                if(++counter >= angle) {
                    counter = 0;
                    stateServo = 3;
                }
            }
            break;
        case 3:
            SPIN();
            break;        
        case 4:
            if (TiGetTics(timerServo) >= 2){
                TiResetTics(timerServo);
                STOP();
                stateServo = 5;
            }
            break;

        case 5:
            if (TiGetTics(timerServo) >= 18){
                TiResetTics(timerServo);
                SPIN();
                stateServo = 4;
                if(++counter >= angle) {
                    counter = 0;
                    stateServo = 6;
                    if(++warmUp == 5) stateServo = 3;
                }
            }
            break;      
        case 6:
            if (TiGetTics(timerServo)>=3000){
                SPIN();
                TiResetTics(timerServo);
                stateServo = 4;
            }
            break;                  

    }   
}

void setNumber(int number) {
    angle = 143 + number; 
    SiPutsCooperatiu("\r\n\n\tAngle: ");                
    mymyItoa(angle, 4, sendAngle);                    
    SiPutsCooperatiu(sendAngle);
    SiPutsCooperatiu("\r\n\n");   

}

void changeServoStatus() {
    if(stateServo == 3) {
        stateServo = 0;
    } else {
        stateServo = 3;
    }
}

int translate(int userBet) {
    switch(userBet) {
        case 0:
            setNumber(0);
            return 0;
            break;
        case 1:
            setNumber(9);        
            return 14;            
            break;
        case 2:
            setNumber(21);        
            return 31;            
            break;
        case 3:
            setNumber(1);        
            return 2;            
            break;
        case 4:
            setNumber(22);        
            return 33;            
            break;
        case 5:
            setNumber(12);
            return 18;                    
            break;
        case 6:
            setNumber(18);
            return 27;                    
            break;
        case 7:
            setNumber(4);        
            return 6;            
            break;
        case 8:
            setNumber(14);        
            return 21;            
            break;
        case 9:
            setNumber(7);        
            return 10;            
            break;
        case 10:
            setNumber(13);        
            return 19;            
            break;
        case 11:
            setNumber(15);        
            return 23;            
            break;
        case 12:
            setNumber(3);        
            return 4;            
            break;
        case 13:
            setNumber(17);        
            return 25;            
            break;
        case 14:
            setNumber(8);        
            return 12;            
            break; 
        case 15:
            setNumber(23);        
            return 35;
            break;
        case 16:
            setNumber(11);        
            return 16; 
            break;
        case 17:
            setNumber(19);        
            return 29;            
            break;
        case 18:
            setNumber(5);        
            return 8; 
            break;
        case 19:
            setNumber(23);        
            return 34; 
            break;
        case 20:
            setNumber(9);        
            return 13;            
            break;
        case 21:
            setNumber(21);        
            return 32;            
            break;
        case 22:
            setNumber(6);        
            return 9;            
            break;
        case 23:
            setNumber(13);        
            return 20;            
            break;
        case 24:
            setNumber(11);        
            return 17;            
            break;
        case 25:
            setNumber(20);        
            return 20;            
            break;
        case 26:
            setNumber(1);        
            return 1;            
            break;
        case 27:
            setNumber(17);        
            return 26;            
            break;
        case 28:
            setNumber(3); 
            return 5;            
            break;
        case 29:
            setNumber(5);        
            return 7; 
            break;   
        case 30:
            setNumber(15);        
            return 22;            
            break;
        case 31:
            setNumber(7);        
            return 11;            
            break;
        case 32:
            setNumber(24); 
            return 36;            
            break;
        case 33:
            setNumber(10);        
            return 15;            
            break;
        case 34:
            setNumber(19);        
            return 28;            
            break;
        case 35:
            setNumber(2);        
            return 3;            
            break;
        case 36:
            setNumber(16);        
            return 24;            
            break;                                                                                                                                                                                              
    }
}

