/* 
 * File:   PbTPushbutton.h
 * Author: JNM
 *
 * TAD Que controla un parell de pulsadors i te un motor per filtrar els rebots
 *
 * Created on 27 de enero de 2014, 19:19
 */

#ifndef TEMPERATURE_H
#define	TEMPERATURE_H

#define clkH() LATAbits.LATA2 = 1;
#define clkL() LATAbits.LATA2 = 0;
#define csH() LATBbits.LATB11 = 1;
#define csL() LATBbits.LATB11 = 0;
#define temp()  (PORTAbits.RA3);

#include<xc.h>
#include "time.h"
#include "SiTSio.h"
#include "intAscii.h"

void initTemp(void);
//Posa els ports d'entrada i demana un timer!
void MotorTemp();

#endif	/* TEMPERATURE */

