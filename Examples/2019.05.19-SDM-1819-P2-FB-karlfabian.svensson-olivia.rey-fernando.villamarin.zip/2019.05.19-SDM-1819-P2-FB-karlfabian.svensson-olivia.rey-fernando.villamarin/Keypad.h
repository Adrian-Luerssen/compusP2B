/* 
 * File:   Keypad.h
 * Author: JNM
 *
 * Placa de test per al PIC18F4321 controla el backlight del LCD, te un menu
 * interactiu pel SIO, i refresca l'estat dels periferics (2 pulsadors, 2 switchos,
 * 1 entrada analogica)
 * 
 */


#ifndef KEYPAD_H
#define	KEYPAD_H
#include <xc.h>
#include "SiTSio.h"
#include "intAscii.h"


#define SetRow4()			   	LATBbits.LATB9 = 1;
#define SetRow3()			   	LATBbits.LATB8 = 1;
#define SetRow2()				LATBbits.LATB7 = 1;
#define SetRow1()				LATBbits.LATB6 = 1;
#define ClrRow4()		    	LATBbits.LATB9 = 0;
#define ClrRow3()		    	LATBbits.LATB8 = 0;
#define ClrRow2()	    		LATBbits.LATB7 = 0;
#define ClrRow1()   			LATBbits.LATB6 = 0;
#define Col1()                  (PORTBbits.RB12)
#define Col2()                  (PORTBbits.RB13)
#define Col3()                  (PORTBbits.RB14)
#define SetRowsOutput()         (TRISBbits.TRISB9 = TRISBbits.TRISB8 = TRISBbits.TRISB7 = TRISBbits.TRISB6 = 0)
#define SetRowsInput()          (TRISBbits.TRISB9 = TRISBbits.TRISB8 = TRISBbits.TRISB7 = TRISBbits.TRISB6 = 1)
#define ClrRows()               (LATBbits.LATB9 = LATBbits.LATB8 = LATBbits.LATB7 = LATBbits.LATB6 = 0)
#define SetRows()               (LATBbits.LATB9 = LATBbits.LATB8 = LATBbits.LATB7 = LATBbits.LATB6 = 1)
#define SetColsInput()	        (TRISBbits.TRISB14 = TRISBbits.TRISB13 = TRISBbits.TRISB12 = 1)


void initKeypad(void);

void MotorKeypad(void);

char getAsterisc(void);
char getHashtag(void);
char getPress(void);
void resetPress(void);
char getNumber(void);


#endif	/* KEYPAD */

