/*
 * This file basically does the analog to digital conversion continuously 
 * on the bit AN0. This is pin 2, Vanalog.
*/

#include "AdTADC.h"

void AdInit(void){
    TRISAbits.TRISA0 = 1;
    //AD1PCFGbits.PCFG0=1; //Per provar si escolta l'entrada digital

    AD1CON1bits.ADSIDL=1; //Sempre converteix
    AD1CON1bits.FORM1=AD1CON1bits.FORM0=0; //Right aligned
    AD1CON1bits.SSRC0=AD1CON1bits.SSRC1=AD1CON1bits.SSRC2=1; //Auto convert

    AD1CON2bits.VCFG=0; //Referncies VDD i VSS
    AD1CON2bits.CSCNA = 0; //No escanejis, concentra't en RA0!
    AD1CON2bits.BUFM = 1; //El buffer son 2 paraules de 8 bits

    AD1CON3 = 0x0100;
    AD1CHS= 0;
    AD1CSSL = 0x0001;

    AD1CON1bits.ADON=1;  //Activa't
    AD1CON1bits.SAMP=1;
    AD1CON1bits.ASAM=1;  //Despres d'una conversio la seguent

    //AD1CON1bits.ASAM=0;  //Wait for SAMP bit
    //AD1CON1bits.SAMP=0;

}

//If we want to control the ad conversion
/*
void AdStartSampling(void) {
    AD1CON1bits.SAMP=1;
}

void AdStopSampling(void) {
    AD1CON1bits.SAMP=0;
}
*/

int getADConversion(void){
    return ADC1BUF0;
}