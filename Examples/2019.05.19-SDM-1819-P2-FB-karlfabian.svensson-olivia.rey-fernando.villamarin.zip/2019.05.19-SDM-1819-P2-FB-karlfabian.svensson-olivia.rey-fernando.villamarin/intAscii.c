/*
 * Ascii to int and viceversa conversion
*/

#include "intAscii.h"

void mymyItoa(int num, int len, char * s) {
    int i = 0;
    int divider, j;
    for(i=0;i<len;i++) {
        divider = 1;
        for(j=0;j<len-i-1;j++) divider *= 10;
        s[i] = (char)(num/divider);
        num = num - (s[i]*divider);
        s[i] += '0';
    }
    s[len] = '\0';
}