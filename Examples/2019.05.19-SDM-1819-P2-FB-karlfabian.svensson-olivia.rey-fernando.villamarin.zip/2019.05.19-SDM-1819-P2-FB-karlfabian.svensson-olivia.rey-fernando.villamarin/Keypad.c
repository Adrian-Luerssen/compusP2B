#include "Keypad.h"


static char timerKeypad, stateKeypad;
static char row, col, press;
static char sendRow[2], sendCol[2];

char colsPressed(void) {
    return ((PORTBbits.RB14 == 1) || (PORTBbits.RB13 == 1) || (PORTBbits.RB12 == 1));
}

void initKeypad(void){
    SetRowsOutput();
    SetColsInput();
    ClrRows();
    timerKeypad= TiGetTimer();
    stateKeypad = 0;
    TiResetTics(timerKeypad);
    press = 0;
    AD1PCFGbits.PCFG10 = 1;
    AD1PCFGbits.PCFG11 = 1;
    AD1PCFGbits.PCFG12 = 1;        
}

void MotorKeypad(void) {

    SetRowsOutput();
    switch(stateKeypad) {        
        case 0:            
            if(TiGetTics(timerKeypad) >= 20) {
                SetColsInput();
                SetRow1();
                row = 1;
                if(PORTBbits.RB12 == 1) {
                    TiResetTics(timerKeypad);
                    col = 1;
                    stateKeypad = 4;
                } else if(PORTBbits.RB13 == 1) {
                    TiResetTics(timerKeypad);
                    col = 2;
                    stateKeypad = 4;
                }else if(PORTBbits.RB14 == 1) {
                    TiResetTics(timerKeypad);
                    col = 3;
                    stateKeypad = 4;
                } else {                    
                    TiResetTics(timerKeypad);
                    stateKeypad = 1;        
                }
            } 
            ClrRow1();                
            break;
        case 1:
            if(TiGetTics(timerKeypad)) {
                SetRow2();
                row = 2;
                if(Col1() == 1) {
                    TiResetTics(timerKeypad);
                    col = 1;
                    stateKeypad = 4;
                } else if(Col2() == 1) {
                    TiResetTics(timerKeypad);
                    col = 2;
                    stateKeypad = 4;
                }else if(Col3() == 1) {
                    TiResetTics(timerKeypad);
                    col = 3;
                    stateKeypad = 4;
                } else {
                    TiResetTics(timerKeypad);
                    stateKeypad = 2; 
                }
            }
            ClrRow2();                                  
            break;
        case 2:
            if(TiGetTics(timerKeypad)) {
                SetRow3();
                row = 3;
                if(Col1() == 1) {
                    TiResetTics(timerKeypad);
                    col = 1;
                    stateKeypad = 4;
                } else if(Col2() == 1) {
                    TiResetTics(timerKeypad);
                    col = 2;
                    stateKeypad = 4;
                }else if(Col3() == 1) {
                    TiResetTics(timerKeypad);
                    col = 3;
                    stateKeypad = 4;
                } else {
                    TiResetTics(timerKeypad);
                    stateKeypad = 3;
                }
            }
            ClrRow3();                                     
            break;
        case 3:
            if(TiGetTics(timerKeypad)) {
                SetRow4();
                row = 4;
                if(Col1() == 1) {
                    TiResetTics(timerKeypad);
                    col = 1;
                    stateKeypad = 4;
                } else if(Col2() == 1) {
                    TiResetTics(timerKeypad);
                    col = 2;
                    stateKeypad = 4;
                }else if(Col3() == 1) {
                    TiResetTics(timerKeypad);
                    col = 3;
                    stateKeypad = 4;
                } else {
                    TiResetTics(timerKeypad);
                    stateKeypad = 0;
                }
            }
            ClrRow4();                            
            break;     
        case 4:
            if (TiGetTics(timerKeypad) >= 40) {        
                press = 1;
                stateKeypad = 5;    

            }        
            break;            

        case 5:
            SetRows();
            if(!colsPressed()) {
                stateKeypad = 6;
                TiResetTics(timerKeypad);
            } else {
                stateKeypad = 0;
            }
            ClrRows();
            break;
        case 6:
            if (TiGetTics(timerKeypad) >= 40) {
                stateKeypad = 0;
                /*
                SiPutsCooperatiu("\n\rOutput row then col: ");  
                mymyItoa(row, 1, sendRow);                            
                SiPutsCooperatiu(sendRow);                                  
                mymyItoa(col, 1, sendCol);                            
                SiPutsCooperatiu(sendCol);                 
                */
            }
            break;            
    }
}

char getNumber(void) {
    switch(row) {
        case 1:
            if(col == 1) return '1';
            if(col == 2) return '2';
            if(col == 3) return '3';
            break;
        case 2:
            if(col == 1) return '4';
            if(col == 2) return '5';
            if(col == 3) return '6';
            break;
        case 3:
            if(col == 1) return '7';
            if(col == 2) return '8';
            if(col == 3) return '9';
            break;
        case 4:
            if(col == 1) return '*';
            if(col == 2) return '0';
            if(col == 3) return '#';
            break;                                    
    }
}

char getAsterisc(void) {
    if(row == 4) return (col == 1 ? 1:0);
    return 0;
}

char getHashtag(void) {
    if(row == 4) return (col == 3 ? 1:0);
    return 0;
}

char getPress(void) {
    return press;
}

void resetPress(void) {
    press = 0;
    row = 0;
    col = 0;
    SiPutsCooperatiu("\n\rOutput row then col: ");  
    mymyItoa(row, 1, sendRow);                            
    SiPutsCooperatiu(sendRow);                                  
    mymyItoa(col, 1, sendCol);                            
    SiPutsCooperatiu(sendCol);       
}

/*char getCol1() {

}
*/
