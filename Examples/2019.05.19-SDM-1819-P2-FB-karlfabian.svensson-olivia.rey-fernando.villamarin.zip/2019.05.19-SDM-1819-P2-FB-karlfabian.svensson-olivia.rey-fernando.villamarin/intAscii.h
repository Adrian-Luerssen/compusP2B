/* 
 * File:   TOKENS.h
 * Author: JNM
 *
 * Created on 27 de enero de 2014, 19:53
 * No em despentino massa... Aquest TAD esta unicament dissenyat per a que funcioni
 * amb el canal AN0. Passo de tot, converteixo a tota llet i no genero interrupcions,
 * qui vulgui una mostra que l'agafi.
 */

#ifndef INTASCII_H
#define	INTASCII_H

#include <xc.h>

void mymyItoa(int num, int len, char * s);


#endif	/* INTASCII */

