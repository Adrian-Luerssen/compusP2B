/*
 * Token management
*/

#include "Tokens.h"

static int tokens, tokensWon, tokensLost;

void initTokens(void){
    tokens = 99;
    tokensWon = 0;
    tokensLost = 0;
}

void addTokens(int add) {
    if((tokens + add) <= 999) {
        tokens += add;
        tokensWon += add;
    } else {
        tokensWon += (999 - tokens);
        tokens = 999;
    }    
}

void removeTokens(int remove) {
    if((tokens - remove) >= 0) {
        tokens -= remove;
        tokensLost += remove;
    } else {
        tokensLost += tokens;
        tokens = 0;        
    }
}

int getTokens(void) {
    return tokens;
}

void correctColor(int bet) {
    addTokens(bet);

}

void correctCell(int bet) {
    addTokens(bet*36);   
}

void incorrectBet(int bet) {
    removeTokens(bet);
}

int getTokensWon(void) {
    return tokensWon;
}

int getTokensLost(void) {
    return tokensLost;
}