#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> 

void initTX();
void motorTX();
void motorRX();
void sendMyTX(char send);
char TXgetState();


#endif	/* XC_HEADER_TEMPLATE_H */

