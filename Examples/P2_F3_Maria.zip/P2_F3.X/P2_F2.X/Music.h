#include <xc.h>

void initMusic();

void motorMusic();

void startMusic();

void endMusic();

void playNote(char note);