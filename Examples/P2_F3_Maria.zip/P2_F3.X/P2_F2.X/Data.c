#include "Data.h"

void initData(){
    /*
    numUsers = 0;	
    for (char i = 0; i<MAXUSERS+1; i++){
        for (char t = 0; t<10; t++){
            users[i].username[t] = ' ';
        }
    }
    for(char j = 0; j<5; j++){
        topScores[j].score = 0; 
    }
     */
}



