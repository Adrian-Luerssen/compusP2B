/* 
 * File:   Speaker.h
 * Author: alfon
 *
 * Created on 12 May 2022, 19:52
 */

#ifndef SPEAKER_H
#define	SPEAKER_H

void initSpeaker (void);

void motorSpeaker (void);

void SPPlay (void);

void SPOneSec (void);

#endif	/* SPEAKER_H */

