/* 
 * File:   LCon.h
 * Author: alfon
 *
 * Created on 10 May 2022, 15:14
 */

#ifndef LCON_H
#define	LCON_H





#endif	/* LCON_H */

