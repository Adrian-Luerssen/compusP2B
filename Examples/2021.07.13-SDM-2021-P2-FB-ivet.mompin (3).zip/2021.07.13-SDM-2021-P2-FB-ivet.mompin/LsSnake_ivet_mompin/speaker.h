
#ifndef SPEAKER_H
#define	SPEAKER_H

#include <xc.h>
#include "TTimer.h"

char state_speaker;
void InitSpeaker();
void motorSpeaker();

#endif 